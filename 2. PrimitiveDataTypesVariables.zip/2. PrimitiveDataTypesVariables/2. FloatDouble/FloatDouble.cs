﻿using System;

class FloatDouble
{
    static void Main()
    {
        float a = 12.345f;
        float b = 3456.091f;
        double c = 34.567839023;
        double d = 8923.1234857;

        Console.WriteLine("float {0}", a);
        Console.WriteLine("float {0}", b);
        Console.WriteLine("double {0}", c);
        Console.WriteLine("double {0}", d);
    }
}

