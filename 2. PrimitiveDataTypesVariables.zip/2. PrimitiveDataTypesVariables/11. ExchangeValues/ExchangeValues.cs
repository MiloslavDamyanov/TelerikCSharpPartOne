﻿using System;

class ExchangeValues
{
    static void Main()
    {
        int five= 5;
        int ten = 10;
        int temp;

        temp = five;
        five = ten;
        ten = temp;
    }
}
