﻿using System;

class BoolVariable
{
    static void Main()
    {
        bool isFemale = false;
        Console.WriteLine(isFemale);
    }
}

