﻿using System;

class HexFormat
{
    static void Main()
    {
        int myNumber = 0xFE;

        Console.WriteLine(myNumber);
    }
}

