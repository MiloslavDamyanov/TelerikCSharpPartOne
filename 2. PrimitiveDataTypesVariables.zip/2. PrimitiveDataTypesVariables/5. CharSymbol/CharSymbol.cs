﻿using System;

class CharSymbol
{
    static void Main()
    {
        char symbol = '\u0048';
        Console.WriteLine("\n\tUnicode code {0}", (int)symbol);
        Console.WriteLine("\tSymbol is: {0}\n", symbol);
    }
}

