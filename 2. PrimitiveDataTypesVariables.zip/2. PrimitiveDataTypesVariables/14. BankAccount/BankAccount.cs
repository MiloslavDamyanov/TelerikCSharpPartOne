﻿using System;

class BankAccount
    {
        static void Main()
        {
            String firstName = "Иван";
            String middleName = "Петров";
            String lastName = "Господинов";
            decimal balance = 1050M;
            dynamic iban = "BG29STSA93000020277806";
            int bicCode = 284;
            long firstCard = 4890006221392363;
            long secondCard = 4380006620522381;
            long thirdCard = 4524006020392353;
        }
    }

