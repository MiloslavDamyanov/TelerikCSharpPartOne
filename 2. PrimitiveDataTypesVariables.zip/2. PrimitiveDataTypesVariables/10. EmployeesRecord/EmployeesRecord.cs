﻿using System;

class EmployeesRecord
{
    static void Main()
    {
        string firstName = "Ivan";
        string surnameName = "Ivanov";
        int age = 26;
        char gener = 'm';
        ulong idNum = 870523141L;
        ulong uniqueEmployeeNum = 27563456L;
        Console.WriteLine("\tName: {0} {1} \n\tage {2} \n\tgener: {3} \n\tID number: {4} \n\tUnique employee number: {5}",firstName,surnameName,age,gener,idNum,uniqueEmployeeNum);
    }
}
