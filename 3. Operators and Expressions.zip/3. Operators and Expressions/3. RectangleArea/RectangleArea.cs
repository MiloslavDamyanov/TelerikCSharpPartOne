﻿using System;

class RectangleArea
{
    static void Main()
    {
        int width = 22;
        int height = 45;
        int area = width * height;

        Console.WriteLine(area);
    }
}

