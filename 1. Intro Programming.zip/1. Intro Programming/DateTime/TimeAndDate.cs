﻿using System;

class TimeAndDate
{
    static void Main()
    {
        Console.WriteLine("\n\tCurrent date and time is: " + DateTime.Now + " " + DateTime.Now.DayOfWeek + "\n");
    }
}

