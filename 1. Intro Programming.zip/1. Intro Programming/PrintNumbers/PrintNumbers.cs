﻿using System;

class PrintNumbers
{
    static void Main()
    {
        Console.WriteLine("\n\t1" + "\n\t101" + "\n\t1001\n");
    }
}