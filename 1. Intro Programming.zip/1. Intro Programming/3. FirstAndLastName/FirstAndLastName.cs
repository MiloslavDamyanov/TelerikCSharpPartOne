﻿using System;

class FristAndLastName
{
    static void Main()
    {
        Console.WriteLine("\n\tMiloslav Damyanov\n");
    }
}

